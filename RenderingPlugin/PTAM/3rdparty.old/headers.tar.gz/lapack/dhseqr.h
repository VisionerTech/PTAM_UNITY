#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dhseqr_(char *job, char *compz, integer *n, integer *ilo, integer *ihi, doublereal *h__, integer *ldh, doublereal *wr, doublereal *wi, doublereal *z__, integer *ldz, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif