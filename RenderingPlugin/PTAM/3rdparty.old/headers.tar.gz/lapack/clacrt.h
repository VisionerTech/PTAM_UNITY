#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacrt_(integer *n, complex *cx, integer *incx, complex *cy, integer *incy, complex *c__, complex *s);

#ifdef __cplusplus
}
#endif