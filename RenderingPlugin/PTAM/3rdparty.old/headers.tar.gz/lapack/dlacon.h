#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlacon_(integer *n, doublereal *v, doublereal *x, integer *isgn, doublereal *est, integer *kase);

#ifdef __cplusplus
}
#endif