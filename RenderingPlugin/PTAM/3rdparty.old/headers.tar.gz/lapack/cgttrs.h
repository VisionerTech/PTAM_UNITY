#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgttrs_(char *trans, integer *n, integer *nrhs, complex *dl, complex *d__, complex *du, complex *du2, integer *ipiv, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif