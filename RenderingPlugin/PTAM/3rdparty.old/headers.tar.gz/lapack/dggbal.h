#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dggbal_(char *job, integer *n, doublereal *a, integer *lda, doublereal *b, integer *ldb, integer *ilo, integer *ihi, doublereal *lscale, doublereal *rscale, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif