#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarnv_(integer *idist, integer *iseed, integer *n, complex *x);

#ifdef __cplusplus
}
#endif