#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpotrs_(char *uplo, integer *n, integer *nrhs, complex *a, integer *lda, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif