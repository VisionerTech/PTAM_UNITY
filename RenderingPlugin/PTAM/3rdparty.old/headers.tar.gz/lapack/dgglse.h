#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgglse_(integer *m, integer *n, integer *p, doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *c__, doublereal *d__, doublereal *x, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif