#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clanht_(char *norm, integer *n, real *d__, complex *e);

#ifdef __cplusplus
}
#endif