#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpbtrf_(char *uplo, integer *n, integer *kd, complex *ab, integer *ldab, integer *info);

#ifdef __cplusplus
}
#endif