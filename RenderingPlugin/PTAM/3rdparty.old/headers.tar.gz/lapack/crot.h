#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int crot_(integer *n, complex *cx, integer *incx, complex *cy, integer *incy, real *c__, complex *s);

#ifdef __cplusplus
}
#endif