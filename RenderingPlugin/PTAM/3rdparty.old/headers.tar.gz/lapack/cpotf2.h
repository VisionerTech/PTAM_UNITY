#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpotf2_(char *uplo, integer *n, complex *a, integer *lda, integer *info);

#ifdef __cplusplus
}
#endif