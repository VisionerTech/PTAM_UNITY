#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dggbak_(char *job, char *side, integer *n, integer *ilo, integer *ihi, doublereal *lscale, doublereal *rscale, integer *m, doublereal *v, integer *ldv, integer *info);

#ifdef __cplusplus
}
#endif