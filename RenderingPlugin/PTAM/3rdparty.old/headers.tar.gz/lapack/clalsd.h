#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clalsd_(char *uplo, integer *smlsiz, integer *n, integer *nrhs, real *d__, real *e, complex *b, integer *ldb, real *rcond, integer *rank, complex *work, real *rwork, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif