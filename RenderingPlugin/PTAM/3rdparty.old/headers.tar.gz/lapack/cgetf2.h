#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgetf2_(integer *m, integer *n, complex *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif