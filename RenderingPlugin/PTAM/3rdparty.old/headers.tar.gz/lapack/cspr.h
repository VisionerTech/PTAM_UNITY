#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cspr_(char *uplo, integer *n, complex *alpha, complex *x, integer *incx, complex *ap);

#ifdef __cplusplus
}
#endif