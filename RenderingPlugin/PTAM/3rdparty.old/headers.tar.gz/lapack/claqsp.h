#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claqsp_(char *uplo, integer *n, complex *ap, real *s, real *scond, real *amax, char *equed);

#ifdef __cplusplus
}
#endif