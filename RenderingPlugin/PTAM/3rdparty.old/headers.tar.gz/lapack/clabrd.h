#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clabrd_(integer *m, integer *n, integer *nb, complex *a, integer *lda, real *d__, real *e, complex *tauq, complex *taup, complex *x, integer *ldx, complex *y, integer *ldy);

#ifdef __cplusplus
}
#endif