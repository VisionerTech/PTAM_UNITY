#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgesc2_(integer *n, doublereal *a, integer *lda, doublereal *rhs, integer *ipiv, integer *jpiv, doublereal *scale);

#ifdef __cplusplus
}
#endif