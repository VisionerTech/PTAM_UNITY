#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgebal_(char *job, integer *n, complex *a, integer *lda, integer *ilo, integer *ihi, real *scale, integer *info);

#ifdef __cplusplus
}
#endif