#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgecon_(char *norm, integer *n, complex *a, integer *lda, real *anorm, real *rcond, complex *work, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif