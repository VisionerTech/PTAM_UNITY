#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaeda_(integer *n, integer *tlvls, integer *curlvl, integer *curpbm, integer *prmptr, integer *perm, integer *givptr, integer *givcol, doublereal *givnum, doublereal *q, integer *qptr, doublereal *z__, doublereal *ztemp, integer *info);

#ifdef __cplusplus
}
#endif