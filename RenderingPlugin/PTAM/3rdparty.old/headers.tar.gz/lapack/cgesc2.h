#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgesc2_(integer *n, complex *a, integer *lda, complex *rhs, integer *ipiv, integer *jpiv, real *scale);

#ifdef __cplusplus
}
#endif