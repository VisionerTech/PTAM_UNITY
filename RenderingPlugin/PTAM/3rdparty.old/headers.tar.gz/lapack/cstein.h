#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cstein_(integer *n, real *d__, real *e, integer *m, real *w, integer *iblock, integer *isplit, complex *z__, integer *ldz, real *work, integer *iwork, integer *ifail, integer *info);

#ifdef __cplusplus
}
#endif