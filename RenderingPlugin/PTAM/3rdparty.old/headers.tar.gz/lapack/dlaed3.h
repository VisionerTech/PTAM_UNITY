#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed3_(integer *k, integer *n, integer *n1, doublereal *d__, doublereal *q, integer *ldq, doublereal *rho, doublereal *dlamda, doublereal *q2, integer *indx, integer *ctot, doublereal *w, doublereal *s, integer *info);

#ifdef __cplusplus
}
#endif