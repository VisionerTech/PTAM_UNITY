#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clatrz_(integer *m, integer *n, integer *l, complex *a, integer *lda, complex *tau, complex *work);

#ifdef __cplusplus
}
#endif