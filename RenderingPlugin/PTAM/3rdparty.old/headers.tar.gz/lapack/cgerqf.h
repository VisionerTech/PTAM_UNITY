#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgerqf_(integer *m, integer *n, complex *a, integer *lda, complex *tau, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif