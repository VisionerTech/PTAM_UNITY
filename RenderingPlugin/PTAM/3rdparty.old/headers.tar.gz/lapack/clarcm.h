#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarcm_(integer *m, integer *n, real *a, integer *lda, complex *b, integer *ldb, complex *c__, integer *ldc, real *rwork);

#ifdef __cplusplus
}
#endif