#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clangb_(char *norm, integer *n, integer *kl, integer *ku, complex *ab, integer *ldab, real *work);

#ifdef __cplusplus
}
#endif