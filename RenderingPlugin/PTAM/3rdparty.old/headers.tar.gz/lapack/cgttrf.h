#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgttrf_(integer *n, complex *dl, complex *d__, complex *du, complex *du2, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif