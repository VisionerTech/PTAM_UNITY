#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cupgtr_(char *uplo, integer *n, complex *ap, complex *tau, complex *q, integer *ldq, complex *work, integer *info);

#ifdef __cplusplus
}
#endif