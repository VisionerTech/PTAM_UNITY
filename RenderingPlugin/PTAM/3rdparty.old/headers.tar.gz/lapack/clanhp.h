#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clanhp_(char *norm, char *uplo, integer *n, complex *ap, real *work);

#ifdef __cplusplus
}
#endif