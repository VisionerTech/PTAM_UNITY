#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clags2_(logical *upper, real *a1, complex *a2, real *a3, real *b1, complex *b2, real *b3, real *csu, complex *snu, real *csv, complex *snv, real *csq, complex *snq);

#ifdef __cplusplus
}
#endif