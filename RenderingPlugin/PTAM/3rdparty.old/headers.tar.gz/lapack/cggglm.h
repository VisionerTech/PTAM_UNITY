#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cggglm_(integer *n, integer *m, integer *p, complex *a, integer *lda, complex *b, integer *ldb, complex *d__, complex *x, complex *y, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif