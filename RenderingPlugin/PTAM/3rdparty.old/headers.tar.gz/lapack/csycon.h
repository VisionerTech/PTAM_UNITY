#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csycon_(char *uplo, integer *n, complex *a, integer *lda, integer *ipiv, real *anorm, real *rcond, complex *work, integer *info);

#ifdef __cplusplus
}
#endif