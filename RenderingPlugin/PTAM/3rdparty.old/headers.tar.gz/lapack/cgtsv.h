#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgtsv_(integer *n, integer *nrhs, complex *dl, complex *d__, complex *du, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif