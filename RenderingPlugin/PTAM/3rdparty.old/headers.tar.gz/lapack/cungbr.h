#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cungbr_(char *vect, integer *m, integer *n, integer *k, complex *a, integer *lda, complex *tau, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif