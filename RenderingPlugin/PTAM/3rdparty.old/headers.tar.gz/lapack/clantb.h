#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clantb_(char *norm, char *uplo, char *diag, integer *n, integer *k, complex *ab, integer *ldab, real *work);

#ifdef __cplusplus
}
#endif