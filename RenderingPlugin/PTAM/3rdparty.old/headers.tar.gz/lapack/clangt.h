#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clangt_(char *norm, integer *n, complex *dl, complex *d__, complex *du);

#ifdef __cplusplus
}
#endif