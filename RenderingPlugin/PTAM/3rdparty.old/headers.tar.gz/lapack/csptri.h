#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csptri_(char *uplo, integer *n, complex *ap, integer *ipiv, complex *work, integer *info);

#ifdef __cplusplus
}
#endif