#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctrsna_(char *job, char *howmny, logical *select, integer *n, complex *t, integer *ldt, complex *vl, integer *ldvl, complex *vr, integer *ldvr, real *s, real *sep, integer *mm, integer *m, complex *work, integer *ldwork, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif