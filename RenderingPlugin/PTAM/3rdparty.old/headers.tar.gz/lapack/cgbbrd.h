#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgbbrd_(char *vect, integer *m, integer *n, integer *ncc, integer *kl, integer *ku, complex *ab, integer *ldab, real *d__, real *e, complex *q, integer *ldq, complex *pt, integer *ldpt, complex *c__, integer *ldc, complex *work, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif