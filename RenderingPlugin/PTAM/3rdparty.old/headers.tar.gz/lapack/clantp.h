#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clantp_(char *norm, char *uplo, char *diag, integer *n, complex *ap, real *work);

#ifdef __cplusplus
}
#endif