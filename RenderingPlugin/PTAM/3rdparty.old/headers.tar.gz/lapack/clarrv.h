#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarrv_(integer *n, real *d__, real *l, integer *isplit, integer *m, real *w, integer *iblock, real *gersch, real *tol, complex *z__, integer *ldz, integer *isuppz, real *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif