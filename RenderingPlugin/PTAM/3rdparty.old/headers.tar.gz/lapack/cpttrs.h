#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpttrs_(char *uplo, integer *n, integer *nrhs, real *d__, complex *e, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif