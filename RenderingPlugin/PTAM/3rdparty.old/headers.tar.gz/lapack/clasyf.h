#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clasyf_(char *uplo, integer *n, integer *nb, integer *kb, complex *a, integer *lda, integer *ipiv, complex *w, integer *ldw, integer *info);

#ifdef __cplusplus
}
#endif