#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cptts2_(integer *iuplo, integer *n, integer *nrhs, real *d__, complex *e, complex *b, integer *ldb);

#ifdef __cplusplus
}
#endif