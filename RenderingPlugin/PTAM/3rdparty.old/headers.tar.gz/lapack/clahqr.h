#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clahqr_(logical *wantt, logical *wantz, integer *n, integer *ilo, integer *ihi, complex *h__, integer *ldh, complex *w, integer *iloz, integer *ihiz, complex *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif