#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed1_(integer *n, doublereal *d__, doublereal *q, integer *ldq, integer *indxq, doublereal *rho, integer *cutpnt, doublereal *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif