#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clar1v_(integer *n, integer *b1, integer *bn, real *sigma, real *d__, real *l, real *ld, real *lld, real *gersch, complex *z__, real *ztz, real *mingma, integer *r__, integer *isuppz, real *work);

#ifdef __cplusplus
}
#endif