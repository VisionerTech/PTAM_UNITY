#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacon_(integer *n, complex *v, complex *x, real *est, integer *kase);

#ifdef __cplusplus
}
#endif