#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cunmr3_(char *side, char *trans, integer *m, integer *n, integer *k, integer *l, complex *a, integer *lda, complex *tau, complex *c__, integer *ldc, complex *work, integer *info);

#ifdef __cplusplus
}
#endif