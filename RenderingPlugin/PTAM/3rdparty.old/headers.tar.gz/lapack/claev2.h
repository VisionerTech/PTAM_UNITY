#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claev2_(complex *a, complex *b, complex *c__, real *rt1, real *rt2, real *cs1, complex *sn1);

#ifdef __cplusplus
}
#endif