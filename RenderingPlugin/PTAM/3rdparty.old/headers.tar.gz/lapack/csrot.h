#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csrot_(integer *n, complex *cx, integer *incx, complex *cy, integer *incy, real *c__, real *s);

#ifdef __cplusplus
}
#endif