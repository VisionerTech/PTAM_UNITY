#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgeqp3_(integer *m, integer *n, complex *a, integer *lda, integer *jpvt, complex *tau, complex *work, integer *lwork, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif