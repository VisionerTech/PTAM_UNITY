#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpbcon_(char *uplo, integer *n, integer *kd, complex *ab, integer *ldab, real *anorm, real *rcond, complex *work, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif