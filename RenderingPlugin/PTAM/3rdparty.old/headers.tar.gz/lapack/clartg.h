#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clartg_(complex *f, complex *g, real *cs, complex *sn, complex *r__);

#ifdef __cplusplus
}
#endif