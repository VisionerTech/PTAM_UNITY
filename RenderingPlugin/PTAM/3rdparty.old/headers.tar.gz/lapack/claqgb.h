#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claqgb_(integer *m, integer *n, integer *kl, integer *ku, complex *ab, integer *ldab, real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, char *equed);

#ifdef __cplusplus
}
#endif