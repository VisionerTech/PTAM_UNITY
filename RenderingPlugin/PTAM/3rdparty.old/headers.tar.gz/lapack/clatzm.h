#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clatzm_(char *side, integer *m, integer *n, complex *v, integer *incv, complex *tau, complex *c1, complex *c2, integer *ldc, complex *work);

#ifdef __cplusplus
}
#endif