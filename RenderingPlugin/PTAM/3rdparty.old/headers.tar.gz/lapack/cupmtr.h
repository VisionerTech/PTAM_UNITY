#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cupmtr_(char *side, char *uplo, char *trans, integer *m, integer *n, complex *ap, complex *tau, complex *c__, integer *ldc, complex *work, integer *info);

#ifdef __cplusplus
}
#endif