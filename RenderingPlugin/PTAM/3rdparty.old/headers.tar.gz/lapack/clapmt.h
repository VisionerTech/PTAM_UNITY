#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clapmt_(logical *forwrd, integer *m, integer *n, complex *x, integer *ldx, integer *k);

#ifdef __cplusplus
}
#endif