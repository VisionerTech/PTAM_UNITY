#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cptcon_(integer *n, real *d__, complex *e, real *anorm, real *rcond, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif