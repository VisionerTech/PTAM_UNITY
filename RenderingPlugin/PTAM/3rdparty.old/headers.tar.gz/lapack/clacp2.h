#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacp2_(char *uplo, integer *m, integer *n, real *a, integer *lda, complex *b, integer *ldb);

#ifdef __cplusplus
}
#endif