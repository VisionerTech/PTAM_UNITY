#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgeqr2_(integer *m, integer *n, doublereal *a, integer *lda, doublereal *tau, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif