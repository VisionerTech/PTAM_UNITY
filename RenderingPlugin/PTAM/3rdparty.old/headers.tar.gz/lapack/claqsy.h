#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claqsy_(char *uplo, integer *n, complex *a, integer *lda, real *s, real *scond, real *amax, char *equed);

#ifdef __cplusplus
}
#endif