#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgbtrf_(integer *m, integer *n, integer *kl, integer *ku, complex *ab, integer *ldab, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif