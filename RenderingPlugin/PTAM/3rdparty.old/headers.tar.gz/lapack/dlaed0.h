#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed0_(integer *icompq, integer *qsiz, integer *n, doublereal *d__, doublereal *e, doublereal *q, integer *ldq, doublereal *qstore, integer *ldqs, doublereal *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif