#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clansy_(char *norm, char *uplo, integer *n, complex *a, integer *lda, real *work);

#ifdef __cplusplus
}
#endif