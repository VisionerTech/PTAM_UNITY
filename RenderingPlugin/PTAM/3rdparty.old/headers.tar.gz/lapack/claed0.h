#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claed0_(integer *qsiz, integer *n, real *d__, real *e, complex *q, integer *ldq, complex *qstore, integer *ldqs, real *rwork, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif