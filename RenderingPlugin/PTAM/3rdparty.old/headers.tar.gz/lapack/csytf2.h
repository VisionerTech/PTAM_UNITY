#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csytf2_(char *uplo, integer *n, complex *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif