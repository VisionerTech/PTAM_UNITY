#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacgv_(integer *n, complex *x, integer *incx);

#ifdef __cplusplus
}
#endif