#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dggrqf_(integer *m, integer *p, integer *n, doublereal *a, integer *lda, doublereal *taua, doublereal *b, integer *ldb, doublereal *taub, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif