#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgebrd_(integer *m, integer *n, doublereal *a, integer *lda, doublereal *d__, doublereal *e, doublereal *tauq, doublereal *taup, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif