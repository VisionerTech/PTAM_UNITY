#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cspcon_(char *uplo, integer *n, complex *ap, integer *ipiv, real *anorm, real *rcond, complex *work, integer *info);

#ifdef __cplusplus
}
#endif