#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cung2l_(integer *m, integer *n, integer *k, complex *a, integer *lda, complex *tau, complex *work, integer *info);

#ifdef __cplusplus
}
#endif