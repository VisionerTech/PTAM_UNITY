#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctrsyl_(char *trana, char *tranb, integer *isgn, integer *m, integer *n, complex *a, integer *lda, complex *b, integer *ldb, complex *c__, integer *ldc, real *scale, integer *info);

#ifdef __cplusplus
}
#endif