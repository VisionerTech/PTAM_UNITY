#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgelsy_(integer *m, integer *n, integer *nrhs, doublereal *a, integer *lda, doublereal *b, integer *ldb, integer *jpvt, doublereal *rcond, integer *rank, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif