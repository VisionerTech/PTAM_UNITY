#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clantr_(char *norm, char *uplo, char *diag, integer *m, integer *n, complex *a, integer *lda, real *work);

#ifdef __cplusplus
}
#endif