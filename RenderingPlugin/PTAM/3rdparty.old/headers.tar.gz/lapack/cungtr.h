#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cungtr_(char *uplo, integer *n, complex *a, integer *lda, complex *tau, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif