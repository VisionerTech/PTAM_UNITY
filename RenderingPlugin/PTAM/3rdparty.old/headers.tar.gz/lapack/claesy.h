#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claesy_(complex *a, complex *b, complex *c__, complex *rt1, complex *rt2, complex *evscal, complex *cs1, complex *sn1);

#ifdef __cplusplus
}
#endif