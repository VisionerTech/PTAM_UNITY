#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgebrd_(integer *m, integer *n, complex *a, integer *lda, real *d__, real *e, complex *tauq, complex *taup, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif