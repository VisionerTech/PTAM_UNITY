#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgebak_(char *job, char *side, integer *n, integer *ilo, integer *ihi, doublereal *scale, integer *m, doublereal *v, integer *ldv, integer *info);

#ifdef __cplusplus
}
#endif