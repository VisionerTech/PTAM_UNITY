#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clascl_(char *type__, integer *kl, integer *ku, real *cfrom, real *cto, integer *m, integer *n, complex *a, integer *lda, integer *info);

#ifdef __cplusplus
}
#endif