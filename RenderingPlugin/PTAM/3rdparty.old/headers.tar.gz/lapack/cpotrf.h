#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpotrf_(char *uplo, integer *n, complex *a, integer *lda, integer *info);

#ifdef __cplusplus
}
#endif