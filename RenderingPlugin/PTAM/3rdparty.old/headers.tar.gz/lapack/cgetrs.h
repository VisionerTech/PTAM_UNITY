#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgetrs_(char *trans, integer *n, integer *nrhs, complex *a, integer *lda, integer *ipiv, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif