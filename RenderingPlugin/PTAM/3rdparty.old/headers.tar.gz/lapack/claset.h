#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claset_(char *uplo, integer *m, integer *n, complex *alpha, complex *beta, complex *a, integer *lda);

#ifdef __cplusplus
}
#endif