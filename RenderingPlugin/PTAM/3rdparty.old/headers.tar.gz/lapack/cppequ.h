#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cppequ_(char *uplo, integer *n, complex *ap, real *s, real *scond, real *amax, integer *info);

#ifdef __cplusplus
}
#endif