#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed9_(integer *k, integer *kstart, integer *kstop, integer *n, doublereal *d__, doublereal *q, integer *ldq, doublereal *rho, doublereal *dlamda, doublereal *w, doublereal *s, integer *lds, integer *info);

#ifdef __cplusplus
}
#endif