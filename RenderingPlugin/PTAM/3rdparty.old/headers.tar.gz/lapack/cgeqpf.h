#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgeqpf_(integer *m, integer *n, complex *a, integer *lda, integer *jpvt, complex *tau, complex *work, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif