#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clar2v_(integer *n, complex *x, complex *y, complex *z__, integer *incx, real *c__, complex *s, integer *incc);

#ifdef __cplusplus
}
#endif