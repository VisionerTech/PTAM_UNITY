#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgecon_(char *norm, integer *n, doublereal *a, integer *lda, doublereal *anorm, doublereal *rcond, doublereal *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif