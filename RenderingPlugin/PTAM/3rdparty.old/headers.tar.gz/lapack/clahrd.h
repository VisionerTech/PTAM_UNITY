#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clahrd_(integer *n, integer *k, integer *nb, complex *a, integer *lda, complex *tau, complex *t, integer *ldt, complex *y, integer *ldy);

#ifdef __cplusplus
}
#endif