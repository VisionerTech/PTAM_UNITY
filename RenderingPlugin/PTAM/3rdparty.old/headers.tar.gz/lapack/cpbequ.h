#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpbequ_(char *uplo, integer *n, integer *kd, complex *ab, integer *ldab, real *s, real *scond, real *amax, integer *info);

#ifdef __cplusplus
}
#endif