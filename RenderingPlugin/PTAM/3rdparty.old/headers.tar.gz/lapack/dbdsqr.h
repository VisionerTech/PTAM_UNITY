#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dbdsqr_(char *uplo, integer *n, integer *ncvt, integer *nru, integer *ncc, doublereal *d__, doublereal *e, doublereal *vt, integer *ldvt, doublereal *u, integer *ldu, doublereal *c__, integer *ldc, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif