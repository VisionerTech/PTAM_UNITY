#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgghrd_(char *compq, char *compz, integer *n, integer *ilo, integer *ihi, complex *a, integer *lda, complex *b, integer *ldb, complex *q, integer *ldq, complex *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif