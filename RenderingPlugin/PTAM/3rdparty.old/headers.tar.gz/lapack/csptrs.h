#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csptrs_(char *uplo, integer *n, integer *nrhs, complex *ap, integer *ipiv, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif