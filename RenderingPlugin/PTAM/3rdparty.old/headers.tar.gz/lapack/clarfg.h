#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarfg_(integer *n, complex *alpha, complex *x, integer *incx, complex *tau);

#ifdef __cplusplus
}
#endif