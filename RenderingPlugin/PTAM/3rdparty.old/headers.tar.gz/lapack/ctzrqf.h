#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctzrqf_(integer *m, integer *n, complex *a, integer *lda, complex *tau, integer *info);

#ifdef __cplusplus
}
#endif