#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarf_(char *side, integer *m, integer *n, complex *v, integer *incv, complex *tau, complex *c__, integer *ldc, complex *work);

#ifdef __cplusplus
}
#endif