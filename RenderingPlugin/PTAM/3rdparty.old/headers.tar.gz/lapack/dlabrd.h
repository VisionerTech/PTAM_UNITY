#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlabrd_(integer *m, integer *n, integer *nb, doublereal *a, integer *lda, doublereal *d__, doublereal *e, doublereal *tauq, doublereal *taup, doublereal *x, integer *ldx, doublereal *y, integer *ldy);

#ifdef __cplusplus
}
#endif