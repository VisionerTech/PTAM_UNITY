#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clargv_(integer *n, complex *x, integer *incx, complex *y, integer *incy, real *c__, integer *incc);

#ifdef __cplusplus
}
#endif