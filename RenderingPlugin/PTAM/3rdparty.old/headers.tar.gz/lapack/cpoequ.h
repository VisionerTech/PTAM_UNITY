#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpoequ_(integer *n, complex *a, integer *lda, real *s, real *scond, real *amax, integer *info);

#ifdef __cplusplus
}
#endif