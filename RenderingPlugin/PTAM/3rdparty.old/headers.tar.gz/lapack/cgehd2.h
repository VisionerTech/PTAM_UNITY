#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgehd2_(integer *n, integer *ilo, integer *ihi, complex *a, integer *lda, complex *tau, complex *work, integer *info);

#ifdef __cplusplus
}
#endif