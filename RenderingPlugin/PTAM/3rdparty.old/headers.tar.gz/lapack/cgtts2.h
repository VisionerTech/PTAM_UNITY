#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgtts2_(integer *itrans, integer *n, integer *nrhs, complex *dl, complex *d__, complex *du, complex *du2, integer *ipiv, complex *b, integer *ldb);

#ifdef __cplusplus
}
#endif