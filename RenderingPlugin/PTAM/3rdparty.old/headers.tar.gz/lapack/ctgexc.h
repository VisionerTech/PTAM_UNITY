#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctgexc_(logical *wantq, logical *wantz, integer *n, complex *a, integer *lda, complex *b, integer *ldb, complex *q, integer *ldq, complex *z__, integer *ldz, integer *ifst, integer *ilst, integer *info);

#ifdef __cplusplus
}
#endif