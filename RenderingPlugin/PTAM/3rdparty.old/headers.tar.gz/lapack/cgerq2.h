#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgerq2_(integer *m, integer *n, complex *a, integer *lda, complex *tau, complex *work, integer *info);

#ifdef __cplusplus
}
#endif