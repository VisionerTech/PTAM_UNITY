#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed2_(integer *k, integer *n, integer *n1, doublereal *d__, doublereal *q, integer *ldq, integer *indxq, doublereal *rho, doublereal *z__, doublereal *dlamda, doublereal *w, doublereal *q2, integer *indx, integer *indxc, integer *indxp, integer *coltyp, integer *info);

#ifdef __cplusplus
}
#endif