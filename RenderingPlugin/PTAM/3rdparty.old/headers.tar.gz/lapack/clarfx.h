#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarfx_(char *side, integer *m, integer *n, complex *v, complex *tau, complex *c__, integer *ldc, complex *work);

#ifdef __cplusplus
}
#endif