#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clatbs_(char *uplo, char *trans, char *diag, char *normin, integer *n, integer *kd, complex *ab, integer *ldab, complex *x, real *scale, real *cnorm, integer *info);

#ifdef __cplusplus
}
#endif