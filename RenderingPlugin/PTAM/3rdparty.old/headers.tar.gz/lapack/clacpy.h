#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacpy_(char *uplo, integer *m, integer *n, complex *a, integer *lda, complex *b, integer *ldb);

#ifdef __cplusplus
}
#endif