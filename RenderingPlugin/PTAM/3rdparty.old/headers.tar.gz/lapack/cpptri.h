#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpptri_(char *uplo, integer *n, complex *ap, integer *info);

#ifdef __cplusplus
}
#endif