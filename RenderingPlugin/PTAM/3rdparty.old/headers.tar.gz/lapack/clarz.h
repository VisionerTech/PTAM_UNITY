#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarz_(char *side, integer *m, integer *n, integer *l, complex *v, integer *incv, complex *tau, complex *c__, integer *ldc, complex *work);

#ifdef __cplusplus
}
#endif