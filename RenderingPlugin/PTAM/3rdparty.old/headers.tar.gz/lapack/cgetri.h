#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgetri_(integer *n, complex *a, integer *lda, integer *ipiv, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif