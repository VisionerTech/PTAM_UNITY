#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgtts2_(integer *itrans, integer *n, integer *nrhs, doublereal *dl, doublereal *d__, doublereal *du, doublereal *du2, integer *ipiv, doublereal *b, integer *ldb);

#ifdef __cplusplus
}
#endif