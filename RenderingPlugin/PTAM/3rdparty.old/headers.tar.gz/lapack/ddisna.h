#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ddisna_(char *job, integer *m, integer *n, doublereal *d__, doublereal *sep, integer *info);

#ifdef __cplusplus
}
#endif