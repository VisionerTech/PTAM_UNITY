#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csrscl_(integer *n, real *sa, complex *sx, integer *incx);

#ifdef __cplusplus
}
#endif