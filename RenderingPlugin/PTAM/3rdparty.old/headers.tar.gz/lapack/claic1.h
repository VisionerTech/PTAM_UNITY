#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claic1_(integer *job, integer *j, complex *x, real *sest, complex *w, complex *gamma, real *sestpr, complex *s, complex *c__);

#ifdef __cplusplus
}
#endif