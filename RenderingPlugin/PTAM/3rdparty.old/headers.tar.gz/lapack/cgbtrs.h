#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgbtrs_(char *trans, integer *n, integer *kl, integer *ku, integer *nrhs, complex *ab, integer *ldab, integer *ipiv, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif