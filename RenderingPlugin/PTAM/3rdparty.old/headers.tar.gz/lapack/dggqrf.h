#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dggqrf_(integer *n, integer *m, integer *p, doublereal *a, integer *lda, doublereal *taua, doublereal *b, integer *ldb, doublereal *taub, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif