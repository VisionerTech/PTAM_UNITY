#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctptri_(char *uplo, char *diag, integer *n, complex *ap, integer *info);

#ifdef __cplusplus
}
#endif