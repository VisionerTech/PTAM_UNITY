#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clartv_(integer *n, complex *x, integer *incx, complex *y, integer *incy, real *c__, complex *s, integer *incc);

#ifdef __cplusplus
}
#endif