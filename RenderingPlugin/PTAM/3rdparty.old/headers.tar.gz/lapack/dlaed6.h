#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed6_(integer *kniter, logical *orgati, doublereal *rho, doublereal *d__, doublereal *z__, doublereal *finit, doublereal *tau, integer *info);

#ifdef __cplusplus
}
#endif