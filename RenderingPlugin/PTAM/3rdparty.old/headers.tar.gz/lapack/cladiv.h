#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

C_f cladiv_(complex * ret_val, complex *x, complex *y);

#ifdef __cplusplus
}
#endif