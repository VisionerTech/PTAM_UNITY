#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dggglm_(integer *n, integer *m, integer *p, doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *d__, doublereal *x, doublereal *y, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif