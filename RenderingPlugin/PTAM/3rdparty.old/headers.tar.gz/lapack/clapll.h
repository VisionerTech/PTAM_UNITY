#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clapll_(integer *n, complex *x, integer *incx, complex *y, integer *incy, real *ssmin);

#ifdef __cplusplus
}
#endif