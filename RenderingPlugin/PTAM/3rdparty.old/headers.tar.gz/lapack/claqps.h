#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int claqps_(integer *m, integer *n, integer *offset, integer *nb, integer *kb, complex *a, integer *lda, integer *jpvt, complex *tau, real *vn1, real *vn2, complex *auxv, complex *f, integer *ldf);

#ifdef __cplusplus
}
#endif