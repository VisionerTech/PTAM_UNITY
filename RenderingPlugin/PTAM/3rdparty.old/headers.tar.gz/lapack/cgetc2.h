#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgetc2_(integer *n, complex *a, integer *lda, integer *ipiv, integer *jpiv, integer *info);

#ifdef __cplusplus
}
#endif