#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpbsv_(char *uplo, integer *n, integer *kd, integer *nrhs, complex *ab, integer *ldab, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif