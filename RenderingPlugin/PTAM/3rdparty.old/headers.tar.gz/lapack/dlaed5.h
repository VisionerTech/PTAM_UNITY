#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaed5_(integer *i__, doublereal *d__, doublereal *z__, doublereal *delta, doublereal *rho, doublereal *dlam);

#ifdef __cplusplus
}
#endif