#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctrexc_(char *compq, integer *n, complex *t, integer *ldt, complex *q, integer *ldq, integer *ifst, integer *ilst, integer *info);

#ifdef __cplusplus
}
#endif