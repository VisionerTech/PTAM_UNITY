#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaein_(logical *rightv, logical *noinit, integer *n, doublereal *h__, integer *ldh, doublereal *wr, doublereal *wi, doublereal *vr, doublereal *vi, doublereal *b, integer *ldb, doublereal *work, doublereal *eps3, doublereal *smlnum, doublereal *bignum, integer *info);

#ifdef __cplusplus
}
#endif