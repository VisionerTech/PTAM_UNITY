#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sspr2_(char *uplo, integer *n, real *alpha, real *x, integer *incx, real *y, integer *incy, real *ap);

#ifdef __cplusplus
}
#endif