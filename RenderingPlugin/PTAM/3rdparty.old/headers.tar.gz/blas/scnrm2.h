#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f scnrm2_(integer *n, complex *x, integer *incx);

#ifdef __cplusplus
}
#endif