#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dcabs1_(doublecomplex *z__);

#ifdef __cplusplus
}
#endif