#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctbsv_(char *uplo, char *trans, char *diag, integer *n, integer *k, complex *a, integer *lda, complex *x, integer *incx);

#ifdef __cplusplus
}
#endif