#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zaxpy_(integer *n, doublecomplex *za, doublecomplex *zx, integer *incx, doublecomplex *zy, integer *incy);

#ifdef __cplusplus
}
#endif