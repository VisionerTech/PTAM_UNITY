#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zher_(char *uplo, integer *n, doublereal *alpha, doublecomplex *x, integer *incx, doublecomplex *a, integer *lda);

#ifdef __cplusplus
}
#endif