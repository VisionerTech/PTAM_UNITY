#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sswap_(integer *n, real *sx, integer *incx, real *sy, integer *incy);

#ifdef __cplusplus
}
#endif