#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int drotg_(doublereal *da, doublereal *db, doublereal *c__, doublereal *s);

#ifdef __cplusplus
}
#endif