#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zsymm_(char *side, char *uplo, integer *m, integer *n, doublecomplex *alpha, doublecomplex *a, integer *lda, doublecomplex *b, integer *ldb, doublecomplex *beta, doublecomplex *c__, integer *ldc);

#ifdef __cplusplus
}
#endif