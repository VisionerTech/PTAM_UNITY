#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer idamax_(integer *n, doublereal *dx, integer *incx);

#ifdef __cplusplus
}
#endif