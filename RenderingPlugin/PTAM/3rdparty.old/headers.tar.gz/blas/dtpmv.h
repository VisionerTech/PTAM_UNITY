#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dtpmv_(char *uplo, char *trans, char *diag, integer *n, doublereal *ap, doublereal *x, integer *incx);

#ifdef __cplusplus
}
#endif