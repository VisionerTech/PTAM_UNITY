#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctpmv_(char *uplo, char *trans, char *diag, integer *n, complex *ap, complex *x, integer *incx);

#ifdef __cplusplus
}
#endif