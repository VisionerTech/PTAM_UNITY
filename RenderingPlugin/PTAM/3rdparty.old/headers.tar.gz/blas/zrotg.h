#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zrotg_(doublecomplex *ca, doublecomplex *cb, doublereal *c__, doublecomplex *s);

#ifdef __cplusplus
}
#endif