#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f scasum_(integer *n, complex *cx, integer *incx);

#ifdef __cplusplus
}
#endif