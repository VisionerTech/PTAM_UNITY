#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int srot_(integer *n, real *sx, integer *incx, real *sy, integer *incy, real *c__, real *s);

#ifdef __cplusplus
}
#endif