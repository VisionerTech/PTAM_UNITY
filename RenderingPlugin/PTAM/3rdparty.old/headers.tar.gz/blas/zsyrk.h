#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zsyrk_(char *uplo, char *trans, integer *n, integer *k, doublecomplex *alpha, doublecomplex *a, integer *lda, doublecomplex *beta, doublecomplex *c__, integer *ldc);

#ifdef __cplusplus
}
#endif