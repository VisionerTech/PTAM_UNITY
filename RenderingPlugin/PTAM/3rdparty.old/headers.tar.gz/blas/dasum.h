#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dasum_(integer *n, doublereal *dx, integer *incx);

#ifdef __cplusplus
}
#endif