#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssyr_(char *uplo, integer *n, real *alpha, real *x, integer *incx, real *a, integer *lda);

#ifdef __cplusplus
}
#endif