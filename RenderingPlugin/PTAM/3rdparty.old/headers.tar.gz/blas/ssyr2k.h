#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssyr2k_(char *uplo, char *trans, integer *n, integer *k, real *alpha, real *a, integer *lda, real *b, integer *ldb, real *beta, real *c__, integer *ldc);

#ifdef __cplusplus
}
#endif