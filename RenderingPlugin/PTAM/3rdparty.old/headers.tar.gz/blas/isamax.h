#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer isamax_(integer *n, real *sx, integer *incx);

#ifdef __cplusplus
}
#endif