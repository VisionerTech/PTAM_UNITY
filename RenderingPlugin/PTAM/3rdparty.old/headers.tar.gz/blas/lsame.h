#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

logical lsame_(char *ca, char *cb);

#ifdef __cplusplus
}
#endif